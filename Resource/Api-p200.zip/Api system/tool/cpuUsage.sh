top -n1 | awk '/Cpu\(s\):/ {print $2}'
