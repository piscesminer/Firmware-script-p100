#packet-forward init
cd /userdata/packet/packet/packet_forwarder/
./lora_pkt_fwd &